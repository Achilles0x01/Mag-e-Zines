<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!-- saved from url=(0042)http://invisiblethings.org/tools/redpill.c -->
<HTML><HEAD>
<META http-equiv=Content-Type content="text/html; charset=windows-1252">
<META content="MSHTML 6.00.2900.2523" name=GENERATOR></HEAD>
<BODY><PRE>/* VMM detector, based on SIDT trick
 * written by joanna at invisiblethings.org
 *
 * should compile and run on any Intel based OS
 *
 * http://invisiblethings.org
 */


#include &lt;stdio.h&gt;
int main () {
  unsigned char m[2+4], rpill[] = "\x0f\x01\x0d\x00\x00\x00\x00\xc3";
  *((unsigned*)&amp;rpill[3]) = (unsigned)m;
  ((void(*)())&amp;rpill)();

  printf ("idt base: %#x\n", *((unsigned*)&amp;m[2]));
  if (m[5]&gt;0xd0) printf ("Inside Matrix!\n", m[5]);
  else printf ("Not in Matrix.\n");
  return 0;
}


</PRE></BODY></HTML>
