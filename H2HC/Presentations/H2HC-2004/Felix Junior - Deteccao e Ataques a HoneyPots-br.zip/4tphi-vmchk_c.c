<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!-- saved from url=(0054)http://chitchat.at.infoseek.co.jp/vmware/4tphi-vmchk.c -->
<HTML><HEAD>
<META http-equiv=Content-Type content="text/html; charset=windows-1252">
<META content="MSHTML 6.00.2900.2523" name=GENERATOR></HEAD>
<BODY><PRE>/*
 * 4tphi-vmchk.c
 * Detects if you are in a VMWare virtual machine.
 *
 * Written by Andrew Hintz &lt;http://guh.nu&gt;
 *			  and AAron Walters
 * Fortify Research Laboratories &lt;http://4tphi.net&gt;
 *
 * "Oft at the hives of his tame bees
 *	They would their sugary thirst appease."
 *
 * This program is based on info and code from:
 *	http://chitchat.tripod.co.jp/vmware/
 *	by chitchat@lycos.jp
 *
 * Notes:
 *	The program can be run as a normal user.
 *	We tested the program only in x86 Linux.
 *	The m4dn3ss lives on!
 */

#include &lt;stdio.h&gt;
#include &lt;sys/signal.h&gt;

#if __INTSIZE == 2	/* 16 bit environment */
typedef unsigned int uint16;
typedef unsigned long uint32;
#else		 /* 32 bit environment */
typedef unsigned short uint16;
typedef unsigned int uint32;
#endif	/* __INTSIZE */

void segfault(){
  printf("Not running inside VMware.\n");
  exit(1);
}

int main(){
  uint32 verMajor, verMinor, magic, dout;

  signal(SIGSEGV, segfault);

  __asm__  __volatile__ ("
	mov $0x564D5868, %%eax; /* magic number */
	mov $0x3c6cf712, %%ebx; /* random number */
	mov $0x0000000A, %%ecx; /* specifies command */
	mov $0x5658, %%edx; /* VMware I/O port */

	in %%dx, %%eax;

	mov %%eax, %0;
	mov %%ebx, %1;
	mov %%ecx, %2;
	mov %%edx, %3;
	"
	: "=r"(verMajor), "=r"(magic), "=r"(verMinor), "=r"(dout)
	);

  if (magic == 0x564D5868) {
	printf("Running inside VMware. ");
	printf("(Version %lu,%lu)\n", verMajor, verMinor);
	/* I'm not really sure what the versions mean. */
  }

  return 0;

}/* end main */

/* end of file */
</PRE></BODY></HTML>
